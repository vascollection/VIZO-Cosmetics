===== LilacBeauty Shop =====

LilacBeauty Shop plugin adds shop features for LilacBeauty theme.


== Changelog ==

= 1.0.0 =

    * First release!