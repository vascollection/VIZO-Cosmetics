<?php

/**
 * Listings - Category
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'LilacBeauty_Shop_Listing_Category' ) ) {

    class LilacBeauty_Shop_Listing_Category {

        private static $_instance = null;

        private $settings;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            /* Load Modules */
                $this->load_modules();

        }

        /*
        Load Modules
        */
            function load_modules() {

                /* Customizer */
                    include_once LILACBEAUTY_SHOP_PATH . 'modules/category/customizer/index.php';

            }

    }

}


if( !function_exists('lilacbeauty_shop_listing_category') ) {
	function lilacbeauty_shop_listing_category() {
		return LilacBeauty_Shop_Listing_Category::instance();
	}
}

lilacbeauty_shop_listing_category();