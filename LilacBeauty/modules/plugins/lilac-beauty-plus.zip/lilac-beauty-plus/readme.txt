======= LilacBeauty Plus =====

LilacBeauty Plus plugin adds additonal features for LilacBeauty theme.


== Changelog ==

= 1.0.0 =

    * First release!