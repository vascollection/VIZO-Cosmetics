<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'LilacBeautyProPostSimple' ) ) {
    class LilacBeautyProPostSimple {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_filter( 'lilacbeauty_post_styles', array( $this, 'add_post_styles_option' ) );
            add_action( 'lilacbeauty_hook_container_before', array( $this, 'add_post_hook_container_before' ) );
        }

        function add_post_styles_option( $options ) {
            $options['simple'] = esc_html__('Simple', 'lilac-beauty-pro');
            return $options;
        }

        function add_post_hook_container_before() {

            if(is_singular('post')) {

                $post_id = get_the_ID();

                $post_meta = get_post_meta( $post_id, '_lilacbeauty_post_settings', TRUE );
                $post_meta = is_array( $post_meta ) ? $post_meta  : array();
                $post_style = !empty( $post_meta['single_post_style'] ) ? $post_meta['single_post_style'] : '';

                if($post_style != 'simple') {
                    return;
                }

                $template_args['post_ID'] = $post_id;
                $template_args['post_Style'] = $post_style;
                $template_args = array_merge( $template_args, lilacbeauty_single_post_params() );

                ob_start();
                echo '<div class="post-simple post-header">';
                    if( $template_args['enable_title'] ) :
                        lilacbeauty_template_part( 'post', 'templates/post-extra/title', '', $template_args );
                    endif;
                    lilacbeauty_template_part( 'post', 'templates/post-extra/excerpt', '', $template_args );
                    lilacbeauty_template_part( 'post', 'templates/simple/parts/author', '', $template_args );
                echo '</div>';
                echo ob_get_clean();

            }

        }
    }
}

LilacBeautyProPostSimple::instance();