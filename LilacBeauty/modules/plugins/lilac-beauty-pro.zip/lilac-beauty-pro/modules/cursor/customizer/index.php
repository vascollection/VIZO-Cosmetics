<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'LilacBeautyProCustomizerCursor' ) ) {
    class LilacBeautyProCustomizerCursor {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_filter( 'lilacbeauty_pro_customizer_default', array( $this, 'default' ) );
            add_action( 'lilacbeauty_general_cutomizer_options', array( $this, 'register_general' ), 30 );
        }

        function default( $option ) {

            $option['enable_cursor_effect'] = '1';
            $option['cursor_type'] = 'type-1';
            $option['cursor_link_hover_effect'] = 'link-hover-effect-1';
            $option['cursor_lightbox_hover_effect'] = 'image-hover-effect-1';

            return $option;
        }

        function register_general( $wp_customize ) {

            $wp_customize->add_section(
                new LilacBeauty_Customize_Section(
                    $wp_customize,
                    'cursor-section',
                    array(
                        'title'    => esc_html__('Cursor', 'lilac-beauty-pro'),
                        'panel'    => 'site-general-main-panel',
                        'priority' => 30,
                    )
                )
            );

                /**
                 * Option : Enable Cursor
                 */
                $wp_customize->add_setting(
                    LILACBEAUTY_CUSTOMISER_VAL . '[enable_cursor_effect]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new LilacBeauty_Customize_Control_Switch(
                        $wp_customize, LILACBEAUTY_CUSTOMISER_VAL . '[enable_cursor_effect]', array(
                            'type'    => 'wdt-switch',
                            'section' => 'cursor-section',
                            'label'   => esc_html__( 'Enable Cursor Effect', 'lilac-beauty-pro' ),
                            'choices' => array(
                                'on'  => esc_attr__( 'Yes', 'lilac-beauty-pro' ),
                                'off' => esc_attr__( 'No', 'lilac-beauty-pro' )
                            )
                        )
                    )
                );

                /**
                 * Option : Type
                 */
                /* $wp_customize->add_setting(
                    LILACBEAUTY_CUSTOMISER_VAL . '[cursor_type]', array(
                        'type'    => 'option',
                    )
                );

                $wp_customize->add_control(
                    new LilacBeauty_Customize_Control(
                        $wp_customize, LILACBEAUTY_CUSTOMISER_VAL . '[cursor_type]', array(
                            'type'       => 'select',
                            'section'    => 'cursor-section',
                            'label'      => esc_html__( 'Type', 'lilac-beauty-pro' ),
                            'desc'      => esc_html__( 'Choose one of the available cursor types.', 'lilac-beauty-pro' ),
                            'choices'    => array (
                                'type-1' => esc_html__('Type 1', 'lilac-beauty-pro'),
                                'type-2' => esc_html__('Type 2', 'lilac-beauty-pro'),
                            ),
                            'dependency' => array( 'enable_cursor_effect', '!=', '' ),
                        )
                    )
                ); */

                /**
                 * Option : Link Hover Effect
                 */
                /* $wp_customize->add_setting(
                    LILACBEAUTY_CUSTOMISER_VAL . '[cursor_link_hover_effect]', array(
                        'type'    => 'option',
                    )
                );

                $wp_customize->add_control(
                    new LilacBeauty_Customize_Control(
                        $wp_customize, LILACBEAUTY_CUSTOMISER_VAL . '[cursor_link_hover_effect]', array(
                            'type'       => 'select',
                            'section'    => 'cursor-section',
                            'label'      => esc_html__( 'Link Hover Effect', 'lilac-beauty-pro' ),
                            'desc'      => esc_html__( 'Effects to use if cursor hovers on links.', 'lilac-beauty-pro' ),
                            'choices'    => array (
                                '' => esc_html__('None', 'lilac-beauty-pro'),
                                'link-hover-effect-1' => esc_html__('Effect 1', 'lilac-beauty-pro'),
                                'link-hover-effect-2' => esc_html__('Effect 2', 'lilac-beauty-pro'),
                            ),
                            'dependency' => array( 'enable_cursor_effect', '!=', '' ),
                        )
                    )
                ); */

                /**
                 * Option : LightBox Hover Effect
                 */
                /* $wp_customize->add_setting(
                    LILACBEAUTY_CUSTOMISER_VAL . '[cursor_lightbox_hover_effect]', array(
                        'type'    => 'option',
                    )
                );

                $wp_customize->add_control(
                    new LilacBeauty_Customize_Control(
                        $wp_customize, LILACBEAUTY_CUSTOMISER_VAL . '[cursor_lightbox_hover_effect]', array(
                            'type'       => 'select',
                            'section'    => 'cursor-section',
                            'label'      => esc_html__( 'LightBox Hover Effect', 'lilac-beauty-pro' ),
                            'desc'      => esc_html__( 'Effects to use if cursor hovers on images.', 'lilac-beauty-pro' ),
                            'choices'    => array (
                                '' => esc_html__('None', 'lilac-beauty-pro'),
                                'image-hover-effect-1' => esc_html__('Effect 1', 'lilac-beauty-pro'),
                                'image-hover-effect-2' => esc_html__('Effect 2', 'lilac-beauty-pro'),
                            ),
                            'dependency' => array( 'enable_cursor_effect', '!=', '' ),
                        )
                    )
                ); */

        }

    }
}

LilacBeautyProCustomizerCursor::instance();