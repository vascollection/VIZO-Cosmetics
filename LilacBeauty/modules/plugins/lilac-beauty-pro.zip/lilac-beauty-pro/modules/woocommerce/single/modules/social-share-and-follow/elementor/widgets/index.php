<?php

namespace LilacBeautyElementor\Widgets;
use LilacBeautyElementor\Widgets\LilacBeauty_Shop_Widget_Product_Summary;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;


class LilacBeauty_Shop_Widget_Product_Summary_Extend extends LilacBeauty_Shop_Widget_Product_Summary {

	function dynamic_register_controls() {

		$this->start_controls_section( 'product_summary_extend_section', array(
			'label' => esc_html__( 'Social Options', 'lilac-beauty-pro' ),
		) );

			$this->add_control( 'share_follow_type', array(
				'label'   => esc_html__( 'Share / Follow Type', 'lilac-beauty-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'share',
				'options' => array(
					''       => esc_html__('None', 'lilac-beauty-pro'),
					'share'  => esc_html__('Share', 'lilac-beauty-pro'),
					'follow' => esc_html__('Follow', 'lilac-beauty-pro'),
				),
				'description' => esc_html__( 'Choose between Share / Follow you would like to use.', 'lilac-beauty-pro' ),
			) );

			$this->add_control( 'social_icon_style', array(
				'label'   => esc_html__( 'Social Icon Style', 'lilac-beauty-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					'simple'        => esc_html__( 'Simple', 'lilac-beauty-pro' ),
					'bgfill'        => esc_html__( 'BG Fill', 'lilac-beauty-pro' ),
					'brdrfill'      => esc_html__( 'Border Fill', 'lilac-beauty-pro' ),
					'skin-bgfill'   => esc_html__( 'Skin BG Fill', 'lilac-beauty-pro' ),
					'skin-brdrfill' => esc_html__( 'Skin Border Fill', 'lilac-beauty-pro' ),
				),
				'description' => esc_html__( 'This option is applicable for all buttons used in product summary.', 'lilac-beauty-pro' ),
				'condition'   => array( 'share_follow_type' => array ('share', 'follow') )
			) );

			$this->add_control( 'social_icon_radius', array(
				'label'   => esc_html__( 'Social Icon Radius', 'lilac-beauty-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					'square'  => esc_html__( 'Square', 'lilac-beauty-pro' ),
					'rounded' => esc_html__( 'Rounded', 'lilac-beauty-pro' ),
					'circle'  => esc_html__( 'Circle', 'lilac-beauty-pro' ),
				),
				'condition'   => array(
					'social_icon_style' => array ('bgfill', 'brdrfill', 'skin-bgfill', 'skin-brdrfill'),
					'share_follow_type' => array ('share', 'follow')
				),
			) );

			$this->add_control( 'social_icon_inline_alignment', array(
				'label'        => esc_html__( 'Social Icon Inline Alignment', 'lilac-beauty-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'yes', 'lilac-beauty-pro' ),
				'label_off'    => esc_html__( 'no', 'lilac-beauty-pro' ),
				'default'      => '',
				'return_value' => 'true',
				'description'  => esc_html__( 'This option is applicable for all buttons used in product summary.', 'lilac-beauty-pro' ),
				'condition'   => array( 'share_follow_type' => array ('share', 'follow') )
			) );

		$this->end_controls_section();

	}

}