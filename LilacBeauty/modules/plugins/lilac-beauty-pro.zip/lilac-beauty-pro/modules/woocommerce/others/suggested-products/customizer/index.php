<?php

/**
 * WooCommerce - Single - Module - Suggested Products - Customizer Settings
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'LilacBeauty_Shop_Customizer_Others_Suggested_Products' ) ) {

    class LilacBeauty_Shop_Customizer_Others_Suggested_Products {

        private static $_instance = null;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            add_filter( 'lilacbeauty_woo_others_settings', array( $this, 'others_settings' ), 10, 1 );
            add_action( 'customize_register', array( $this, 'register' ), 15);

        }

        function others_settings( $settings ) {

            $enable_suggested_products                 = lilacbeauty_customizer_settings('wdt-woo-others-enable-suggested-products' );
            $settings['enable_suggested_products']     = $enable_suggested_products;

            return $settings;

        }

        function register( $wp_customize ) {

            /**
            * Option : Enable Suggested Products
            */
                $wp_customize->add_setting(
                    LILACBEAUTY_CUSTOMISER_VAL . '[wdt-woo-others-enable-suggested-products]', array(
                        'type' => 'option'
                    )
                );

                $wp_customize->add_control(
                    new LilacBeauty_Customize_Control_Switch(
                        $wp_customize, LILACBEAUTY_CUSTOMISER_VAL . '[wdt-woo-others-enable-suggested-products]', array(
                            'type'    => 'wdt-switch',
                            'label'   => esc_html__( 'Enable Suggested Products', 'lilac-beauty-pro'),
                            'section' => 'woocommerce-others-section',
                            'choices' => array(
                                'on'  => esc_attr__( 'Yes', 'lilac-beauty-pro' ),
                                'off' => esc_attr__( 'No', 'lilac-beauty-pro' )
                            ),
                            'description'   => esc_html__('Enable suggested products sticky section.', 'lilac-beauty-pro'),
                        )
                    )
                );

        }

    }

}


if( !function_exists('lilacbeauty_shop_customizer_others_suggested_products') ) {
	function lilacbeauty_shop_customizer_others_suggested_products() {
		return LilacBeauty_Shop_Customizer_Others_Suggested_Products::instance();
	}
}

lilacbeauty_shop_customizer_others_suggested_products();