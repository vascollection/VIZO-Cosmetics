===== LilacBeauty Pro =====

LilacBeauty Pro plugin adds advanced features for LilacBeauty theme.


== Changelog ==

= 1.0.1 =

    * Plugin installation issue fixed

= 1.0.0 =

    * First release!