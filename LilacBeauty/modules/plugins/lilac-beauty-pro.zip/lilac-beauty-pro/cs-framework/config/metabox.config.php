<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

CSFramework_Metabox::instance( array() );